export const APP_VERSION = 'V0.7.7.4 UI Version Sync'
