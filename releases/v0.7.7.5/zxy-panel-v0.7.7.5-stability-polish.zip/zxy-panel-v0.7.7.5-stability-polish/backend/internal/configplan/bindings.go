// SPDX-License-Identifier: AGPL-3.0-only
package configplan

import (
	"fmt"
	"sort"
	"strings"
	"time"

	"zxy-panel/backend/internal/model"
)

// ExpectedBindings 从面板期望数据生成必须出现在 Xray 配置里的绑定清单。
// 后期新增 SSL、OpenWRT DNS、云防火墙等能力时，也应继续扩展 BindingCheck，而不是散落在各接口里。
func ExpectedBindings(serverID string, nodes []model.Node, clients []model.Client, relays []model.RelayRoute) []model.BindingCheck {
	now := time.Now()
	checks := make([]model.BindingCheck, 0)
	for _, node := range nodes {
		if !node.Enabled || node.ServerID != serverID || node.Port <= 0 {
			continue
		}
		switch strings.ToLower(strings.TrimSpace(node.Protocol)) {
		case "vless":
			for _, client := range clients {
				if !eligibleNormalClient(client, node.ID, now) {
					continue
				}
				checks = append(checks, model.BindingCheck{
					ServerID: serverID, Port: node.Port, UUID: client.UUID, Type: "vless_client", InboundTag: node.ID, NodeID: node.ID, ClientID: client.ID, Required: true,
				})
			}
		case "socks":
			if strings.TrimSpace(node.SocksUsername) != "" && strings.TrimSpace(node.SocksPassword) != "" {
				checks = append(checks, model.BindingCheck{
					ServerID: serverID, Port: node.Port, Username: node.SocksUsername, Type: "socks_account", InboundTag: node.ID, NodeID: node.ID, Required: true,
				})
			}
		}
	}
	for _, relay := range relays {
		if !relay.Enabled || relay.RelayServerID != serverID || relay.RelayPort <= 0 || relayRouteMode(relay.RouteMode) != "socks5_route" {
			continue
		}
		for _, client := range clients {
			if !eligibleRelayClient(client, relay.ID, now) {
				continue
			}
			checks = append(checks, model.BindingCheck{
				ServerID: serverID, Port: relay.RelayPort, UUID: client.UUID, Type: "vless_client", InboundTag: "in_" + relay.ID, RelayID: relay.ID, ClientID: client.ID, Required: true,
			})
		}
	}
	sort.SliceStable(checks, func(i, j int) bool {
		if checks[i].Port != checks[j].Port {
			return checks[i].Port < checks[j].Port
		}
		if checks[i].UUID != checks[j].UUID {
			return checks[i].UUID < checks[j].UUID
		}
		return checks[i].Username < checks[j].Username
	})
	return checks
}

func ValidateRenderedConfig(cfg map[string]any, checks []model.BindingCheck) error {
	for _, check := range checks {
		switch check.Type {
		case "vless_client":
			if check.UUID == "" || !configHasVlessClient(cfg, check.Port, check.UUID) {
				return fmt.Errorf("config binding mismatch: port %d missing client UUID %s", check.Port, check.UUID)
			}
		case "socks_account":
			if check.Username == "" || !configHasSocksAccount(cfg, check.Port, check.Username) {
				return fmt.Errorf("config binding mismatch: port %d missing SOCKS5 account %s", check.Port, check.Username)
			}
		}
	}
	return nil
}

func eligibleNormalClient(c model.Client, nodeID string, now time.Time) bool {
	if !c.Enabled || c.UUID == "" || (!c.ExpireAt.IsZero() && c.ExpireAt.Before(now)) {
		return false
	}
	// 固定出口客户默认只进入中转入口，避免同一个 UUID 在普通直连和固定出口间串线。
	if len(c.RelayRouteIDs) > 0 && len(c.NodeIDs) == 0 {
		return false
	}
	if len(c.NodeIDs) > 0 && !contains(c.NodeIDs, nodeID) {
		return false
	}
	return true
}

func eligibleRelayClient(c model.Client, relayID string, now time.Time) bool {
	if !c.Enabled || c.UUID == "" || (!c.ExpireAt.IsZero() && c.ExpireAt.Before(now)) {
		return false
	}
	return contains(c.RelayRouteIDs, relayID)
}

func relayRouteMode(v string) string {
	v = strings.ToLower(strings.TrimSpace(v))
	if v == "" {
		return "tcp_forward"
	}
	return v
}

func contains(list []string, v string) bool {
	for _, item := range list {
		if item == v {
			return true
		}
	}
	return false
}
