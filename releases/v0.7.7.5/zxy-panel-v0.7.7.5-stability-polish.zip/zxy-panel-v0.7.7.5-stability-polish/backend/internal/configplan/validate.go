// SPDX-License-Identifier: AGPL-3.0-only
package configplan

import (
	"encoding/json"
	"fmt"
)

func configHasVlessClient(cfg map[string]any, port int, uuid string) bool {
	for _, inbound := range inbounds(cfg) {
		if intFromAny(inbound["port"]) != port {
			continue
		}
		settings, _ := inbound["settings"].(map[string]any)
		if hasClientID(settings["clients"], uuid) {
			return true
		}
	}
	return false
}

func configHasSocksAccount(cfg map[string]any, port int, username string) bool {
	for _, inbound := range inbounds(cfg) {
		if intFromAny(inbound["port"]) != port {
			continue
		}
		settings, _ := inbound["settings"].(map[string]any)
		return hasAccountUser(settings["accounts"], username)
	}
	return false
}

func inbounds(cfg map[string]any) []map[string]any {
	out := []map[string]any{}
	switch items := cfg["inbounds"].(type) {
	case []any:
		for _, item := range items {
			if m, ok := item.(map[string]any); ok {
				out = append(out, m)
			}
		}
	case []map[string]any:
		out = append(out, items...)
	}
	return out
}

func hasClientID(raw any, uuid string) bool {
	switch clients := raw.(type) {
	case []any:
		for _, item := range clients {
			if m, ok := item.(map[string]any); ok && fmt.Sprint(m["id"]) == uuid {
				return true
			}
		}
	case []map[string]any:
		for _, m := range clients {
			if fmt.Sprint(m["id"]) == uuid {
				return true
			}
		}
	}
	return false
}

func hasAccountUser(raw any, username string) bool {
	switch accounts := raw.(type) {
	case []any:
		for _, item := range accounts {
			if m, ok := item.(map[string]any); ok && fmt.Sprint(m["user"]) == username {
				return true
			}
		}
	case []map[string]any:
		for _, m := range accounts {
			if fmt.Sprint(m["user"]) == username {
				return true
			}
		}
	}
	return false
}

func intFromAny(v any) int {
	switch t := v.(type) {
	case int:
		return t
	case int64:
		return int(t)
	case float64:
		return int(t)
	case json.Number:
		i, _ := t.Int64()
		return int(i)
	default:
		return 0
	}
}
