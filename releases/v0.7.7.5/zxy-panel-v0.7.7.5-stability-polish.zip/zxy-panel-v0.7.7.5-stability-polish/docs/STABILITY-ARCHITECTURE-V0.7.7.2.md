# V0.7.7.5 Stability Polish 稳定性说明

本版本基于 V0.7.7.1 正式源码，保留 Clash Verge / Mihomo 订阅、网络策略、备份恢复和安装优化能力。

核心新增：

- BindingCheck：后端下发前校验端口、UUID、SOCKS5 账号绑定。
- Agent apply 二次校验：tmp、正式 config、重启后都检查绑定。
- 客户 PUT 改为 merge update，避免前端局部提交误清空 node_ids / relay_route_ids。
- 系统诊断新增 Xray 绑定一致性。

目标：面板能复制链接时，Xray 配置里必须已经存在同端口、同 UUID。
