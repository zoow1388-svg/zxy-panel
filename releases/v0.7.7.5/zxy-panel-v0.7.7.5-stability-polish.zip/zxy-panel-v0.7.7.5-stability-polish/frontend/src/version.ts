export const APP_VERSION = 'V0.7.7.5 Stability Polish'
